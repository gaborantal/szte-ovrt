package hu.u_szeged.inf.ovrt.iterator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class NewTv extends Tv {

	private List<Channel> channels;

	public NewTv(Channel[] channels) {
		this.channels = new ArrayList<>();
		for (int i = 0; i < channels.length; i++) {
			this.channels.add(channels[i]);
		}
	}

	@Override
	public Iterator<Channel> iterator() {
		return new NewTvIterator();
	}

	private class NewTvIterator implements Iterator<Channel> {
		int current = 0;

		@Override
		public boolean hasNext() {
			return current < channels.size();
		}

		@Override
		public Channel next() {
			if (this.hasNext()) {
				return channels.get(current++);
			}
			return null;
		}

	}
}


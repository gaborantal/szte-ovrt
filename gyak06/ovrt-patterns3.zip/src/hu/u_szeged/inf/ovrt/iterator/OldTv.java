package hu.u_szeged.inf.ovrt.iterator;

import java.util.Iterator;

public class OldTv extends Tv {

	private Channel[] channels;

	public OldTv(Channel[] channels) {
		this.channels = new Channel[10];
		for (int i = 0; i < 10; i++) {
			this.channels[i] = channels[i];
		}
	}

	@Override
	public Iterator<Channel> iterator() {
		return new OldTvIterator();
	}

	private class OldTvIterator implements Iterator<Channel> {
		int current = 0;

		@Override
		public boolean hasNext() {
			return current < 10;
		}

		@Override
		public Channel next() {
			if (this.hasNext()) {
				return channels[current++];
			}
			return null;
		}

	}
}

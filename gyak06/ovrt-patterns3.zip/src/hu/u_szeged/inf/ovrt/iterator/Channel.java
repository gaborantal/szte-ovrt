package hu.u_szeged.inf.ovrt.iterator;

public class Channel {
	public double freq;
	public String name;

	public Channel(String name, double freq) {
		this.name = name;
		this.freq = freq;
	}
}

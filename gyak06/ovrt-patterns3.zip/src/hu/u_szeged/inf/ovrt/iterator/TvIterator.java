package hu.u_szeged.inf.ovrt.iterator;

public interface TvIterator {
	public Channel next();
	public boolean hasNext();
}

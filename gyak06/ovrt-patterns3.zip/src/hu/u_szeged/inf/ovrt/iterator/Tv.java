package hu.u_szeged.inf.ovrt.iterator;

public abstract class Tv implements Iterable<Channel> {
}

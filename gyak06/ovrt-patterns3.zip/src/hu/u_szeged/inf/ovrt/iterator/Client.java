package hu.u_szeged.inf.ovrt.iterator;

public class Client {
	public static void main(String[] args) {
		Channel[] channels = { new Channel("m1", 120.3),
				new Channel("m2", 121.4), new Channel("m3", 134.73),
				new Channel("m4", 150.1), new Channel("rtl1", 220.3),
				new Channel("rtl2", 221.4), new Channel("rtl3", 234.73),
				new Channel("rtl4", 250.1), new Channel("sport1", 320.3),
				new Channel("sport2", 321.4), new Channel("sport3", 334.73),
				new Channel("sport4", 350.1), new Channel("zene1", 420.3),
				new Channel("zene2", 421.4), new Channel("zene3", 434.73),
				new Channel("zene4", 450.1), };

		boolean oldTv = false;
		Tv television;
		if (oldTv) {
			television = new OldTv(channels);
		} else {
			television = new NewTv(channels);
		}

		for (Channel c : television) {
			System.out.println("Egy csatorna a tv-n: " + c.name);
		}

	}
}

package hu.u_szeged.inf.ovrt.factorymethod;

import java.util.ArrayList;
import java.util.List;

public class MusicPlayer {

	private List<String> playlist;

	public void playPlaylist(List<String> playlist) {
		this.createPlaylist(playlist);
		this.play();
	}

	protected void createPlaylist(List<String> playlist) {
		this.playlist = new ArrayList<>(playlist);
	}

	private void play() {
		for (String track : this.playlist) {
			System.out.println("Playing: " + track);
		}
	}

}

package hu.u_szeged.inf.ovrt.factorymethod;

import java.util.Arrays;

public class Client {

	public static void main(String[] args) {
		boolean shuffleIsOn = true;
		MusicPlayer musicPlayer;
		if (shuffleIsOn) {
			musicPlayer = new ShufflePlayer();
		} else {
			musicPlayer = new MusicPlayer();
		}
		musicPlayer.playPlaylist(Arrays.asList("Kozso - Szomoru Szamuraj", "Psy - Gangnam Style"));
	}

}

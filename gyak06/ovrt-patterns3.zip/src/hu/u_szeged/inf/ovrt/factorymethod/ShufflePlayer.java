package hu.u_szeged.inf.ovrt.factorymethod;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ShufflePlayer extends MusicPlayer {

	@Override
	protected void createPlaylist(List<String> playlist) {
		List<String> list = new ArrayList<>(playlist);
		Collections.shuffle(list);
		super.createPlaylist(list);
	}

}

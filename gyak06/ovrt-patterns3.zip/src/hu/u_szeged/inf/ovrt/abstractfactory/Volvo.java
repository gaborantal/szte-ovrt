package hu.u_szeged.inf.ovrt.abstractfactory;

public class Volvo implements ITruck {

	@Override
	public void carry() {
		System.out.println("Carrying stuff with a Volvo truck.");
	}

}

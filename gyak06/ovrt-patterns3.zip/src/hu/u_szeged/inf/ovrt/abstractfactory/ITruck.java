package hu.u_szeged.inf.ovrt.abstractfactory;

public interface ITruck {

	void carry();

}

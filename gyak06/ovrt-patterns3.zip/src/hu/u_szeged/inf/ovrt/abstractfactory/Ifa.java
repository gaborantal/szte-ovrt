package hu.u_szeged.inf.ovrt.abstractfactory;

public class Ifa implements ITruck {

	@Override
	public void carry() {
		System.out.println("Carrying stuff with an IFA.");
	}

}

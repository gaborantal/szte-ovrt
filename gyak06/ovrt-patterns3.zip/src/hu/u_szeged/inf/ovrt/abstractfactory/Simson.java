package hu.u_szeged.inf.ovrt.abstractfactory;

public class Simson implements IBike {

	@Override
	public void ride() {
		System.out.println("Riding a Simson bike.");
	}

}

package hu.u_szeged.inf.ovrt.abstractfactory;

public class Client {

	public static void main(String[] args) {
		VehicleFactory vf;
		boolean nostalgia = true;
		if (nostalgia) {
			vf = new OldVehicleFactory();
		} else {
			vf = new ModernVehicleFactory();
		}

		vf.createBike().ride();
		vf.createCar().drive();
		vf.createTruck().carry();
	}

}

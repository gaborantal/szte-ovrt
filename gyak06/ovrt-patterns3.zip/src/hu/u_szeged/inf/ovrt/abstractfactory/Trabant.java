package hu.u_szeged.inf.ovrt.abstractfactory;

public class Trabant implements ICar {

	@Override
	public void drive() {
		System.out.println("Driving a Trabant.");
	}

}

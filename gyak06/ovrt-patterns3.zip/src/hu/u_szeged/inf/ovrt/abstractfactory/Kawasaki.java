package hu.u_szeged.inf.ovrt.abstractfactory;

public class Kawasaki implements IBike {

	@Override
	public void ride() {
		System.out.println("Riding a Kawasaki bike.");
	}

}

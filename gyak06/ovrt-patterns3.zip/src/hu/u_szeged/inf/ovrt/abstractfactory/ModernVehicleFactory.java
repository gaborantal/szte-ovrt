package hu.u_szeged.inf.ovrt.abstractfactory;

public class ModernVehicleFactory implements VehicleFactory {

	@Override
	public IBike createBike() {
		return new Kawasaki();
	}

	@Override
	public ICar createCar() {
		return new Ford();
	}

	@Override
	public ITruck createTruck() {
		return new Volvo();
	}

}

package hu.u_szeged.inf.ovrt.abstractfactory;

public interface IBike {

	void ride();

}

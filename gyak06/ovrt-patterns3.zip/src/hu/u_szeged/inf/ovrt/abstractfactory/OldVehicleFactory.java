package hu.u_szeged.inf.ovrt.abstractfactory;

public class OldVehicleFactory implements VehicleFactory {

	@Override
	public IBike createBike() {
		return new Simson();
	}

	@Override
	public ICar createCar() {
		return new Trabant();
	}

	@Override
	public ITruck createTruck() {
		return new Ifa();
	}

}

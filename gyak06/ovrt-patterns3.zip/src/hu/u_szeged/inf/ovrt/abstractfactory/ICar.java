package hu.u_szeged.inf.ovrt.abstractfactory;

public interface ICar {

	void drive();

}

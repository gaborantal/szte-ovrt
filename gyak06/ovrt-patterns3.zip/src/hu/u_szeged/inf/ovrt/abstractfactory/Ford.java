package hu.u_szeged.inf.ovrt.abstractfactory;

public class Ford implements ICar {

	@Override
	public void drive() {
		System.out.println("Driving a Ford car.");
	}

}

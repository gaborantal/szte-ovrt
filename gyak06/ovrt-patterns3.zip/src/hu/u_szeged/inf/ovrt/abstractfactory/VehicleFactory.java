package hu.u_szeged.inf.ovrt.abstractfactory;

public interface VehicleFactory {

	IBike createBike();

	ICar createCar();

	ITruck createTruck();

}

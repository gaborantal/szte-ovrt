package hu.u_szeged.inf.ovrt.singleton;

public class SingletonLazyThreadSafe2 {
	private int num = 0;

	private SingletonLazyThreadSafe2() {
	}

	public static SingletonLazyThreadSafe2 getInstance() {
		return SingletonSampleHolder.INSTANCE;
	}

	public void helloSingleton() {
		System.out.println("Hello was said " + ++num + " times");
	}

	// Threadsafe !!
	private static class SingletonSampleHolder {
		private static final SingletonLazyThreadSafe2 INSTANCE = new SingletonLazyThreadSafe2();
	}

	public static void main(String[] args) {
		SingletonLazyThreadSafe2 inst1 = SingletonLazyThreadSafe2.getInstance();
		inst1.helloSingleton();

		SingletonLazyThreadSafe2 inst2 = SingletonLazyThreadSafe2.getInstance();
		inst2.helloSingleton();

		System.out.println(inst1 == inst2);
	}
}

package hu.u_szeged.inf.ovrt.singleton;

/**
 * Singleton with early instantiation. <br>
 * The singleton object is instantiated when the class <br>
 * is loaded and not when it is first used.
 */
public class Singleton {

	/** holds the single instance for the singleton class */
	private static final Singleton INSTANCE = new Singleton();

	/** private constructor -> no other instance can be created */
	private Singleton() {
		System.out.println("> create instance (!)");
	}

	/**
	 * Access method to get the singleton instance.
	 * 
	 * @return the singleton instance
	 */
	public static Singleton getInstance() {
		return INSTANCE;
	}

	public void helloSingleton() {
		System.out.println("Hello! I'm a singleton.");
	}

	// test it
	public static void main(String[] args) {
		System.out.println("> program start");
		Singleton.getInstance().helloSingleton();
		System.out.println("> program finish");
	}
	// Output:
	// > create instance (!)
	// > program start
	// Hello! I'm a singleton.
	// > program finish
}

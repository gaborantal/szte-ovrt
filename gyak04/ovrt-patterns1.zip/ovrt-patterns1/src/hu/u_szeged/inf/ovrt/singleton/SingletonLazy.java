package hu.u_szeged.inf.ovrt.singleton;

/**
 * Singleton with lazy instantiation.
 * 
 * The singleton instance is created when the getInstance() <br>
 * method is called for the first time.
 */
public class SingletonLazy {

	private static SingletonLazy instance;

	private SingletonLazy() {
		System.out.println("> create instance (!)");
	}

	public static SingletonLazy getInstance() {
		if (instance == null) {
			// created only when needed
			instance = new SingletonLazy();
		}
		return instance;
	}

	public void helloSingleton() {
		System.out.println("Hello! I'm a singleton.");
	}

	public static void main(String[] args) {
		System.out.println("> program start");
		SingletonLazy.getInstance().helloSingleton();
		System.out.println("> program finish");
	}

	// Output
	// > program start
	// > create instance (!)
	// Hello! I'm a singleton.
	// > program finish

}

package hu.u_szeged.inf.ovrt.singleton;

/**
 * Singleton implemented as an enum.
 * 
 * + easy implementation <br>
 * + thread-safe <br>
 * ~ early initialization <br>
 * - no inheritance <br>
 */
public enum SingletonEnum {

	INSTANCE;

	public void helloSingleton() {
		System.out.println("Hello! I'm a singleton.");
	}

	
	//// MAIN ////
	public static void main(String[] args) {
		SingletonEnum.INSTANCE.helloSingleton();
	}
}

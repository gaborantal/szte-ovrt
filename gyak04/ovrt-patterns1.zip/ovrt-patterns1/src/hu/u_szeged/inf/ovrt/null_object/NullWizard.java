package hu.u_szeged.inf.ovrt.null_object;

public class NullWizard extends AbstractWizard {

	@Override
	public String getName() {
		return "The customer does not exists";
	}

	@Override
	public boolean isNull() {
		return true;
	}
}
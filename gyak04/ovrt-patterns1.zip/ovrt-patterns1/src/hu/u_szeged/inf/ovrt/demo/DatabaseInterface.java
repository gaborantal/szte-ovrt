package hu.u_szeged.inf.ovrt.demo;

import java.util.List;

import hu.u_szeged.inf.ovrt.null_object.AbstractWizard;

public interface DatabaseInterface {
	public List<AbstractWizard> getWizards();

	public AbstractWizard getWizardByName(String name);
}

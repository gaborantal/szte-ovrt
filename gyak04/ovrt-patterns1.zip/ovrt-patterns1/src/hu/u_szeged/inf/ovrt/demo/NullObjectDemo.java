package hu.u_szeged.inf.ovrt.demo;

import java.util.Scanner;

import hu.u_szeged.inf.ovrt.null_object.AbstractWizard;

public class NullObjectDemo {

	private static final DatabaseInterface db = FakeDatabase.getInstance();
	private static final Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Kezdjuk el! Kit kersz az adatbazisbol?");

		String ans = scanner.nextLine();
		while (!"exit".equals(ans)) {

			AbstractWizard Wizard = db.getWizardByName(ans);

			System.out.println("Neve: " + Wizard.getName());
			System.out.println("Letezo vassarlo? " + (Wizard.isNull() ? "nem" : "igen"));
			ans = scanner.nextLine();
		}
	}
}

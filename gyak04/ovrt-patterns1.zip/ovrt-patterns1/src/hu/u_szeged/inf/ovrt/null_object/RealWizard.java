package hu.u_szeged.inf.ovrt.null_object;

public class RealWizard extends AbstractWizard {

	public RealWizard(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public boolean isNull() {
		return false;
	}
}
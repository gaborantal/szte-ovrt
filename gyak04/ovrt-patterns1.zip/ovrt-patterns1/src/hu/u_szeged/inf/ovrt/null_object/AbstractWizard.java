package hu.u_szeged.inf.ovrt.null_object;

public abstract class AbstractWizard {
	protected String name;

	public abstract boolean isNull();

	public abstract String getName();
}
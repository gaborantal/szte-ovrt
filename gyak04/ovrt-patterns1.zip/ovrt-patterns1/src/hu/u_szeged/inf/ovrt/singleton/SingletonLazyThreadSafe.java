package hu.u_szeged.inf.ovrt.singleton;

/**
 * Thread-safe singleton with lazy instantiation.
 */
public class SingletonLazyThreadSafe {

	private static SingletonLazyThreadSafe instance;

	private SingletonLazyThreadSafe() {
	}

	// ------------------- VERSION SIMPLE >> -----------------------
	// just use synchronized on the getter method
	// + simple method
	// - bad performance because of sync checking
	public static synchronized SingletonLazyThreadSafe getInstanceSimple() {
		if (instance == null) {
			instance = new SingletonLazyThreadSafe();
		}
		return instance;
	}
	// ------------------- << VERSION SIMPLE -----------------------

	// ------------------- VERSION BETTER >> -----------------------
	// only the creation of the instance is synchronized
	private static synchronized void createInstance() {
		if (instance == null) { // double check because of thread magic
			instance = new SingletonLazyThreadSafe();
		}
	}

	// no synchronized needed
	// - a bit more complex
	// + good performance, no sync checking needed
	public static SingletonLazyThreadSafe getInstanceBetter() {
		if (instance == null) {
			createInstance();
		}
		return instance;
	}
	// ------------------- << VERSION BETTER -----------------------

	public void helloSingleton() {
		System.out.println("Hello! I'm a singleton.");
	}

}
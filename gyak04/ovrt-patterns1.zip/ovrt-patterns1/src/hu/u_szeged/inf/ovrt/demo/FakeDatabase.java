package hu.u_szeged.inf.ovrt.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import hu.u_szeged.inf.ovrt.null_object.AbstractWizard;
import hu.u_szeged.inf.ovrt.null_object.NullWizard;
import hu.u_szeged.inf.ovrt.null_object.RealWizard;

public class FakeDatabase implements DatabaseInterface {
	public static final String[] availableWizards = { "harry", "ron", "hermione" };

	@Override
	public List<AbstractWizard> getWizards() {
		List<AbstractWizard> Wizards = new ArrayList<>();

		for (String name : availableWizards) {
			Wizards.add(new RealWizard(name));
		}

		return Collections.unmodifiableList(Wizards);
	}

	@Override
	public AbstractWizard getWizardByName(String name) {
		if (Arrays.asList(availableWizards).contains(name.toLowerCase())) {
			return new RealWizard(name);
		}
		return new NullWizard();
	}

	// Singleton
	private FakeDatabase() {

	}

	public static final FakeDatabase getInstance() {
		return FakeDatabaseHolder.INSTANCE;
	}

	private static class FakeDatabaseHolder {
		private static final FakeDatabase INSTANCE = new FakeDatabase();
	}

}

package hu.u_szeged.inf.ovrt.quiz;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class QuizMain {
	private static final Scanner scanner = new Scanner(System.in);

	public static final List<Question> questions = new ArrayList<>();
	
	public static void main(String[] args) {
		questions.add(new Question("Mikor van ujev elso napja?", "januar 12.", "januar 3.", "januar 1.", "marcius 9", "januar 1.", false));
		questions.add(new Question("6*5+10 = 40. Igaz?", null, null, null, null, null, true));
		questions.add(new Question("6*(5+10) = 40. Igaz?", null, null, null, null, null, false));
		
		int points = 0;
		for(Question q: questions){
			System.out.println(q.questionString());
			String answer = scanner.nextLine();
			points += q.getPointsForAnswer(answer);
		}
		System.out.println("Final score: " + points);
	}
}

package hu.u_szeged.inf.ovrt.calculator;

import java.util.Scanner;

public class CalcMain {
	private static final Scanner scanner = new Scanner(System.in);

	private static final Object multiplyTwoNumbers(int num1, int num2) {
		return new Integer(num1 * num2);
	}

	public static void main(String[] args) {
		int num1;
		int num2;
		String operation;

		System.out.println("Please Enter The Operation");
		operation = scanner.next();

		if (operation.equals("+")) {
			System.out.println("Please Enter The First Number");
			num1 = scanner.nextInt();
			System.out.println("Please Enter The Second Number");
			num2 = scanner.nextInt();

			int result = num1 + num2;
			System.out.println("Your Answer is " + result);
		} else if (operation.equals("-")) {
			System.out.println("Please Enter The First Number");
			num1 = scanner.nextInt();
			System.out.println("Please Enter The Second Number");
			num2 = scanner.nextInt();

			int result = num1 - num2;
			System.out.println("Your Answer is " + result);
		} else if (operation.equals("*")) {
			System.out.println("Please Enter The First Number");
			num1 = scanner.nextInt();
			System.out.println("Please Enter The Second Number");
			num2 = scanner.nextInt();

			int result = (Integer)multiplyTwoNumbers(num1, num2);
			System.out.println("Your Answer is " + result);
		} else if (operation.equals("/")) {
			System.out.println("Please Enter The First Number");
			num1 = scanner.nextInt();
			System.out.println("Please Enter The Second Number");
			num2 = scanner.nextInt();

			int result = num1 / num2;
			System.out.println("Your Answer is " + result);
		} else if (operation.equals("%")) {
			System.out.println("Please Enter The First Number");
			num1 = scanner.nextInt();
			System.out.println("Please Enter The Second Number");
			num2 = scanner.nextInt();

			int result = num1 % num2;
			System.out.println("Your Answer is " + result);
		} else {
			System.out.println("Please Enter The First Number");
			num1 = scanner.nextInt();
			System.out.println("Please Enter The Second Number");
			num2 = scanner.nextInt();

			System.out.println("Your Answer is 42");
		}
	}
}

package hu.u_szeged.inf.ovrt.quiz;

public class Question {
	public String q;
	public String a;
	public String b;
	public String c;
	public String d;
	public String answer;
	public boolean isTrue;

	public Question(String q, String a, String b, String c, String d, String answer, boolean isTrue) {
		this.q = q;
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.answer = answer;
		this.isTrue = isTrue;
	}

	public boolean evaluate(String answer) {
		if (this.answer == null) {
			return this.isTrue == Boolean.valueOf(answer);
		} else {
			return this.answer.equals(answer);
		}
	}

	public int getPointsForAnswer(String answer) {
		if (this.evaluate(answer)) {
			if (this.answer == null) {
				System.out.println("Correct!");
				return 2;
			} else {
				System.out.println("Correct!");
				return 4;
			}
		} else {
			System.out.println("Inorrect!");
			return 0;
		}

	}

	@Override
	public String toString() {
		return String
				.format("Question [q=%s, a=%s, b=%s, c=%s, d=%s, answer=%s, isTrue=%s]",
						q, a, b, c, d, answer, isTrue);
	}
	
	public String questionString(){
		return this.q + "\n\t" + a + "\n\t" + b + "\n\t" + c + "\n\t" + d;
	}

}

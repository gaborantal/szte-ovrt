package hu.u_szeged.inf.ovrt.decorator;

public class ToUpperDecorator extends TextDecorator {

	public ToUpperDecorator(Text text) {
		super(text);
	}

	@Override
	public String get() {
		return super.get().toUpperCase();
	}

}

package hu.u_szeged.inf.ovrt.composite;

import java.util.ArrayList;
import java.util.List;

public class Folder implements Resource {

	private String name;
	private List<Resource> resources = new ArrayList<>();

	public Folder(String name) {
		super();
		this.name = name;
	}

	public void addResource(Resource resource) {
		this.resources.add(resource);
	}

	public List<Resource> getResources() {
		return this.resources;
	}

	@Override
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int getSize() {
		int size = 0;
		for (Resource resource : this.resources) {
			size += resource.getSize();
		}
		return size;
		// In Java 8 you can use this one line:
		// return this.resources.stream().mapToInt(Resource::getSize).sum();
	}

	@Override
	public boolean isDirectory() {
		return true;
	}

	@Override
	public String toString() {
		return "[" + this.name + "]";
	}

}

package hu.u_szeged.inf.ovrt.composite;

import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

public class Commander {

	public static void main(String[] args) {
		Folder root = new Folder("root");
		Folder dev = new Folder("dev");
		root.addResource(dev);
		Folder nul = new Folder("null");
		dev.addResource(nul);
		Folder user = new Folder("student");
		root.addResource(user);
		File readme = new File("readme.txt", 11);
		File linux = new File("debian.iso", 2048);
		user.addResource(readme);
		user.addResource(linux);
		File welcome = new File("motd", 200);
		root.addResource(welcome);

		System.out.println("total size: " + root.getSize() + System.lineSeparator());
		printTree(root);
	}

	public static void printTree(Resource item) {
		class Indent {
			int indent;
			Resource resource;

			public Indent(int indent, Resource resource) {
				super();
				this.indent = indent;
				this.resource = resource;
			}
		}
		Deque<Indent> stack = new LinkedList<>();
		stack.push(new Indent(0, item));
		while (!stack.isEmpty()) {
			Indent parent = stack.pop();
			if (parent.resource.isDirectory()) {
				List<Resource> children = ((Folder) parent.resource).getResources();
				for (int i = children.size() - 1; i >= 0; i--) {
					Resource child = children.get(i);
					stack.push(new Indent(parent.indent + 2, child));
				}
			}
			StringBuilder sBuilder = new StringBuilder();
			for (int i = 0; i < parent.indent; i++) {
				sBuilder.append(" ");
			}
			sBuilder.append(String.format("%s %"
							+ (30 - parent.indent - parent.resource.toString()
									.length()) + "s", parent.resource,
					parent.resource.getSize()));

			System.out.println(sBuilder);
		}
	}

}

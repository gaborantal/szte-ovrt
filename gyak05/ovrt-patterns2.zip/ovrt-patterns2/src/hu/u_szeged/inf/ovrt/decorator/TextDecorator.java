package hu.u_szeged.inf.ovrt.decorator;

public abstract class TextDecorator implements Text {

	private Text text;

	public TextDecorator(Text text) {
		super();
		this.text = text;
	}

	@Override
	public String get() {
		return this.text.get();
	}

}

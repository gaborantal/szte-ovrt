package hu.u_szeged.inf.ovrt.composite;

public interface Resource {

	String getName();

	int getSize();

	boolean isDirectory();

}
package hu.u_szeged.inf.ovrt.decorator;

public class Literal implements Text {

	private String literal;

	public Literal(String literal) {
		this.literal = literal;
	}

	@Override
	public String get() {
		return this.literal;
	}

}

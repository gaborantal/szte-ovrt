package hu.u_szeged.inf.ovrt.decorator;

public class ReverseDecorator extends TextDecorator {

	public ReverseDecorator(Text text) {
		super(text);
	}

	@Override
	public String get() {
		return new StringBuilder(super.get()).reverse().toString();
	}

}

package hu.u_szeged.inf.ovrt.decorator;

public interface Text {

	public String get();

}

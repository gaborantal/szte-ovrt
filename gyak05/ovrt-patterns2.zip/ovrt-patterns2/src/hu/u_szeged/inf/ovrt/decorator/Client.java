package hu.u_szeged.inf.ovrt.decorator;

public class Client {

	public static void main(String[] args) {
		Text text = new Literal("Red rum, sir, is murder!");
		text = new ReverseDecorator(text);
		text = new ToUpperDecorator(text);
		
		System.out.println(text.get());
	}

}

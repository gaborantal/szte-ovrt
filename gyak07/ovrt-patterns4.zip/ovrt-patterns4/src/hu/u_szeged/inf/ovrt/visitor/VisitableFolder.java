package hu.u_szeged.inf.ovrt.visitor;

import java.util.ArrayList;
import java.util.List;

public class VisitableFolder implements VisitableResource {

	private String name;
	private List<VisitableResource> resources = new ArrayList<>();

	public VisitableFolder(String name) {
		super();
		this.name = name;
	}

	public void addResource(VisitableResource resource) {
		this.resources.add(resource);
	}

	public List<VisitableResource> getResources() {
		return this.resources;
	}

	@Override
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int getSize() {
		int size = 0;
		for (VisitableResource resource : this.resources) {
			size += resource.getSize();
		}
		return size;
	}

	@Override
	public boolean isDirectory() {
		return true;
	}

	@Override
	public String toString() {
		return "[" + this.name + "]";
	}

	@Override
	public void accept(FileSystemVisitor visitor) {
		visitor.visit(this);
		for (VisitableResource child : this.getResources()) {
			child.accept(visitor);
		}
		visitor.visitEnd(this);
	}

}

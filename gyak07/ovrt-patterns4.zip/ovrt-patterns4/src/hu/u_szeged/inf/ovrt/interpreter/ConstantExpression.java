package hu.u_szeged.inf.ovrt.interpreter;


public class ConstantExpression implements Expression {

	private String value;

	public ConstantExpression(String value) {
		this.value = value;
	}

	@Override
	public void interpret(Context context) {
		context.addVariable(this, this.value);
	}

}
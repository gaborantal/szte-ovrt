package hu.u_szeged.inf.ovrt.interpreter;


public class ContainsExpression extends ComparisonExpression {

	public ContainsExpression(Expression expressionA, Expression expressionB) {
		super(expressionA, expressionB);
	}

	@Override
	public void interpret(Context c) {
		this.expressionA.interpret(c);
		this.expressionB.interpret(c);
		String exprAResult = c.get(this.expressionA);
		String exprBResult = c.get(this.expressionB);
		boolean result = exprAResult.contains(exprBResult);
		c.addVariable(this, result);
	}

}
package hu.u_szeged.inf.ovrt.interpreter;


public interface Expression {

	void interpret(Context context);

}
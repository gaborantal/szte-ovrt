package hu.u_szeged.inf.ovrt.state;

public class Client {

	public static void main(String[] args) {
		Character orc = new Character("Azog", 100, 20, 5);
		orc.changeStance(new AngryStance());

		Character dwarf = new Character("Thorin", 100, 15, 10);
		dwarf.changeStance(new DefensiveStance());

		boolean turn = true;
		while (orc.isAlive() && dwarf.isAlive()) {
			if (turn) {
				orc.attack(dwarf);
			}
			else {
				dwarf.attack(orc);
			}
			turn = !turn;
		}
		System.out.println("The winner is: " + (orc.isAlive() ? orc : dwarf));
	}

}

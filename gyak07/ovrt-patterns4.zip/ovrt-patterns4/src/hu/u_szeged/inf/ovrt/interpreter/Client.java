package hu.u_szeged.inf.ovrt.interpreter;


import java.util.ArrayList;
import java.util.List;

public class Client {

	public static void main(String[] args) {
		List<Contact> contacts = makeContactList();

		System.out.println("Contents of the ContactList:");
		System.out.println(contacts);
		System.out.println();

		VariableExpression varLName = new VariableExpression(Contact::getLastName);
		ConstantExpression constLName = new ConstantExpression("u");
		ContainsExpression eqLName = new ContainsExpression(varLName, constLName);

		System.out.println("Contents of the search on ContactList:");
		System.out.println("(search was contains 'u' in Lase Name)");
		List<Contact> result = search(eqLName, contacts);
		System.out.println(result);
		System.out.println();

		VariableExpression varTitle = new VariableExpression(Contact::getTitle);
		ConstantExpression constTitle = new ConstantExpression("LT");
		EqualsExpression eqTitle = new EqualsExpression(varTitle, constTitle);

		System.out.println("Contents of the search on ContactList:");
		System.out.println("(search was all LT personnel)");
		result = search(eqTitle, contacts);
		System.out.println(result);
		System.out.println();

		VariableExpression varLastName = new VariableExpression(Contact::getLastName);
		ConstantExpression constLastName = new ConstantExpression("S");
		ContainsExpression cLName = new ContainsExpression(varLastName, constLastName);

		AndExpression andExpr = new AndExpression(eqTitle, cLName);

		System.out.println("Contents of the search on ContactList:");
		System.out.println("(search was all LT personnel with 'S' in Last Name)");
		result = search(andExpr, contacts);
		System.out.println(result);
	}

	private static List<Contact> search(Expression expr, List<Contact> contactList) {
		Context ctx = new Context();
		List<Contact> candidates = new ArrayList<>();
		for (Contact contact : contactList) {
			ctx.setLookup(contact);
			expr.interpret(ctx);
			if (ctx.getBool(expr)) {
				candidates.add(contact);
			}
			ctx.setLookup(null);
		}
		return candidates;
	}

	private static List<Contact> makeContactList() {
		List<Contact> returnList = new ArrayList<>();
		returnList.add(new ContactImpl("James", "Kirk", "Captain", "USS Enterprise"));
		returnList.add(new ContactImpl("Mr.", "Spock", "Science Officer", "USS Enterprise"));
		returnList.add(new ContactImpl("Nyota", "Uhura", "LT", "USS Enterprise"));
		returnList.add(new ContactImpl("Hikaru", "Sulu", "LT", "USS Enterprise"));
		returnList.add(new ContactImpl("Pavel", "Checkov", "Ensign", "USS Enterprise"));
		returnList.add(new ContactImpl("Leonard", "McCoy", "Doctor", "USS Enterprise"));
		returnList.add(new ContactImpl("Montgomery", "Scott", "LT", "USS Enterprise"));
		return returnList;
	}

}

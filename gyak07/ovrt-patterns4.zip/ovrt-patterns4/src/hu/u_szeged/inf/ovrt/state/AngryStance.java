package hu.u_szeged.inf.ovrt.state;

public class AngryStance implements Stance {

	private static final double criticalStrikeChance = 0.3;

	@Override
	public int handleDefense(int defensePower) {
		return 0;
	}

	@Override
	public int handleAttack(int attackPower) {
		return Math.random() > criticalStrikeChance ? attackPower : attackPower * 2;
	}

}

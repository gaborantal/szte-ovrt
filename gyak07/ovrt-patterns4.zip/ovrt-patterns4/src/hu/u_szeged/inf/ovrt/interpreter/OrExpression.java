package hu.u_szeged.inf.ovrt.interpreter;


public class OrExpression extends CompoundExpression {

	public OrExpression(ComparisonExpression expressionA, ComparisonExpression expressionB) {
		super(expressionA, expressionB);
	}

	@Override
	public void interpret(Context c) {
		this.expressionA.interpret(c);
		this.expressionB.interpret(c);
		boolean result = c.getBool(this.expressionA) || c.getBool(this.expressionB);
		c.addVariable(this, result);
	}

}
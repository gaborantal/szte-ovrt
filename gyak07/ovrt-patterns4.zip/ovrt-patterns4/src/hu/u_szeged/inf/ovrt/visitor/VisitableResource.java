package hu.u_szeged.inf.ovrt.visitor;

import hu.u_szeged.inf.ovrt.composite.Resource;

public interface VisitableResource extends Resource {

	void accept(FileSystemVisitor visitor);

}

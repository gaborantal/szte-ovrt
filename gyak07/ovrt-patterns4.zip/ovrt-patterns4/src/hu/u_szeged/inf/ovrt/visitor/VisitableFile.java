package hu.u_szeged.inf.ovrt.visitor;

public class VisitableFile implements VisitableResource {

	private String name;
	private int size;

	public VisitableFile(String name, int size) {
		super();
		this.name = name;
		this.size = size;
	}

	@Override
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSize(int size) {
		this.size = size;
	}

	@Override
	public int getSize() {
		return this.size;
	}

	@Override
	public boolean isDirectory() {
		return false;
	}

	@Override
	public String toString() {
		return this.name;
	}

	@Override
	public void accept(FileSystemVisitor visitor) {
		visitor.visit(this);
	}

}

package hu.u_szeged.inf.ovrt.feladat;

import java.util.Scanner;

class CeilingFanPullChain {
	private int currentState;

	public CeilingFanPullChain() {
		currentState = 0;
	}

	public void pull() {
		if (currentState == 0) {
			currentState = 1;
			System.out.println("low speed");
		} else if (currentState == 1) {
			currentState = 2;
			System.out.println("medium speed");
		} else if (currentState == 2) {
			currentState = 3;
			System.out.println("high speed");
		} else if (currentState == 3) {
			currentState = 4;
			System.out.println("ultra high");
		} else {
			currentState = 0;
			System.out.println("turning off");
		}
	}
}

public class CeilingFanExercise {
	private static final Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		CeilingFanPullChain chain = new CeilingFanPullChain();
		while (true) {
			System.out.print("Press ENTER to pull the ceiling fan!");
			sc.nextLine();
			chain.pull();
		}
	}

}
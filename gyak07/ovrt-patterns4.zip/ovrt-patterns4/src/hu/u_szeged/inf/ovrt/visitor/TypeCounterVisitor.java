package hu.u_szeged.inf.ovrt.visitor;

public class TypeCounterVisitor implements FileSystemVisitor {

	private int folders = 0;
	private int files = 0;

	@Override
	public void visit(VisitableFolder folder) {
		this.folders++;
	}

	@Override
	public void visit(VisitableFile file) {
		this.files++;
	}

	public int getNumberOfFolders() {
		return this.folders;
	}

	public int getNumberOfFiles() {
		return this.files;
	}

	@Override
	public String toString() {
		return "Folders: " + this.folders + " Files: " + this.files;
	}

}

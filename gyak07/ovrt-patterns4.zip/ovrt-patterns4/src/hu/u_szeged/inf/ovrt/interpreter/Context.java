package hu.u_szeged.inf.ovrt.interpreter;


import java.util.HashMap;
import java.util.Map;

public class Context {

	private Map<Expression, Object> map = new HashMap<>();
	private Contact lookup;

	public boolean getBool(Expression expr) {
		return (boolean) this.map.get(expr);
	}

	@SuppressWarnings("unchecked")
	public <E> E get(Expression expr) {
		return (E) this.map.get(expr);
	}

	public void addVariable(Expression expr, Object value) {
		this.map.put(expr, value);
	}

	public Contact getLookup() {
		return this.lookup;
	}

	public void setLookup(Contact lookup) {
		this.lookup = lookup;
	}

}
package hu.u_szeged.inf.ovrt.state;

public class DefensiveStance implements Stance {

	@Override
	public int handleDefense(int defensePower) {
		return defensePower * 2;
	}

	@Override
	public int handleAttack(int attackPower) {
		return attackPower / 2;
	}

}

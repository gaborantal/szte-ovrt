package hu.u_szeged.inf.ovrt.interpreter;


import java.util.function.Function;

public class VariableExpression implements Expression {

	private Function<Contact, String> fieldSelector;

	public VariableExpression(Function<Contact, String> fieldSelector) {
		this.fieldSelector = fieldSelector;
	}

	@Override
	public void interpret(Context c) {
		Contact contact = c.getLookup();
		String fieldValue = this.fieldSelector.apply(contact);
		c.addVariable(this, fieldValue);
	}

}
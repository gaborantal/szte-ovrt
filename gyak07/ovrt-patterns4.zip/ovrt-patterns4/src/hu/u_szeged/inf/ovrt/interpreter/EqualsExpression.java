package hu.u_szeged.inf.ovrt.interpreter;


public class EqualsExpression extends ComparisonExpression {

	public EqualsExpression(Expression expressionA, Expression expressionB) {
		super(expressionA, expressionB);
	}

	@Override
	public void interpret(Context c) {
		this.expressionA.interpret(c);
		this.expressionB.interpret(c);
		boolean result = c.get(this.expressionA).equals(c.get(this.expressionB));
		c.addVariable(this, result);
	}

}
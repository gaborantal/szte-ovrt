package hu.u_szeged.inf.ovrt.visitor;

public class Client {

	public static void main(String[] args) {
		VisitableFolder root = new VisitableFolder("root");
		VisitableFolder dev = new VisitableFolder("dev");
		root.addResource(dev);
		VisitableFolder nul = new VisitableFolder("null");
		dev.addResource(nul);
		VisitableFolder user = new VisitableFolder("student");
		root.addResource(user);
		VisitableFile readme = new VisitableFile("readme.txt", 11);
		VisitableFile linux = new VisitableFile("debian.iso", 2048);
		user.addResource(readme);
		user.addResource(linux);
		VisitableFile welcome = new VisitableFile("motd", 200);
		root.addResource(welcome);

		TypeCounterVisitor tcv = new TypeCounterVisitor();
		root.accept(tcv);
		System.out.println(tcv);

		TreePrinterVisitor tpv = new TreePrinterVisitor();
		root.accept(tpv);
	}

}

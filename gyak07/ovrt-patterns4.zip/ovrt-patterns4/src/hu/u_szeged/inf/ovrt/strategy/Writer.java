package hu.u_szeged.inf.ovrt.strategy;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

interface Strategy{
	public void write(Map<String, String> map);
}

class JsonPrinterStrategy implements Strategy{

	@Override
	public void write(Map<String, String> map) {
		System.out.println("{");
		map.forEach( (k, v) -> {
			System.out.println(String.format("    \"%s\": \"%s\",", k, v));
		});
		System.out.println("}");
	}
	
}

class XmlPrinterStrategy implements Strategy{

	@Override
	public void write(Map<String, String> map) {
		System.out.println("<root>");
		map.forEach( (k, v) -> {
			System.out.println(String.format("    <%s>%s</%s>", k, v, k));
		});
		System.out.println("</root>");
		
	}
	
}


public class Writer {
	private static final Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		Map<String, String> strMap = new HashMap<>();
		strMap.put("name", "John Johny John");
		strMap.put("age", String.valueOf(30));
		strMap.put("fav_music", "Queen");
		
		Strategy s;
		System.out.println("Which strategy to use? (json/xml)");
		String strategy = sc.nextLine();
		if(strategy.equals("json")){
			s = new JsonPrinterStrategy();
		} else {
			s = new XmlPrinterStrategy();
		}
		s.write(strMap);
	}
}

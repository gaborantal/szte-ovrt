package hu.u_szeged.inf.ovrt.visitor;

public interface FileSystemVisitor {

	void visit(VisitableFolder folder);

	default void visitEnd(VisitableFolder folder) {
	}

	void visit(VisitableFile file);

}

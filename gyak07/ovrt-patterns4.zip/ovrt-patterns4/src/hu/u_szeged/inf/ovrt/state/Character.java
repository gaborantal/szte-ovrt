package hu.u_szeged.inf.ovrt.state;

public class Character {

	private String name;
	private int lifePoint;
	private int attackPower;
	private int defensePower;
	private Stance currentStance;

	public Character(String name, int lifePoint, int attackPower, int defensePower) {
		super();
		this.name = name;
		this.lifePoint = lifePoint;
		this.attackPower = attackPower;
		this.defensePower = defensePower;
		this.currentStance = new NormalStance();
	}

	public void changeStance(Stance stance) {
		this.currentStance = stance;
	}

	public void attack(Character enemy) {
		int myAttack = this.currentStance.handleAttack(this.attackPower);
		int enemyDefense = enemy.currentStance.handleDefense(enemy.defensePower);
		int damageToEnemy = Math.max(myAttack - enemyDefense, 0);
		System.out.println(String.format("%s attacked %s with %d. %s lost %d life points, %d remains.", this, enemy,
				myAttack, enemy, damageToEnemy, enemy.lifePoint - damageToEnemy));
		enemy.lifePoint -= damageToEnemy;
	}

	public boolean isAlive() {
		return this.lifePoint > 0;
	}

	@Override
	public String toString() {
		return this.name;
	}

}

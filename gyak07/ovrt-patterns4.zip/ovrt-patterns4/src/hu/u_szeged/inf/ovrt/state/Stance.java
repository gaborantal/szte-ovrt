package hu.u_szeged.inf.ovrt.state;

public interface Stance {

	int handleDefense(int defensePower);

	int handleAttack(int attackPower);

}

package hu.u_szeged.inf.ovrt.feladat;

import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

interface Visitor<T> {
	void visit(Set<T> items);
}

class Music implements Comparable<Music>{
	public String artist;
	public String name;
	public String genre;
	boolean isCompactDisc;
	boolean isMusicDvd;
	
	public Music(String artist, String name, String genre) {
		this.artist = artist;
		this.name = name;
		this.genre = genre;
		this.isCompactDisc = false;
		this.isMusicDvd = false;
	}
	
	public Music(String name, String artist, String genre, boolean isCompactDisc, boolean isMusicDvd) {
		this.artist = artist;
		this.name = name;
		this.genre = genre;
		this.isCompactDisc = isCompactDisc;
		this.isMusicDvd = isMusicDvd;
		
	}


	@Override
	public String toString() {
		return String
				.format("Music [artist=%s, name=%s, genre=%s, isCompactDisc=%s, isMusicDvd=%s]", artist, name, genre, isCompactDisc, isMusicDvd);
	}

	@Override
	public int compareTo(Music o) {
		String tmp1 = this.artist + " " + this.name;
		String tmp2 = o.artist + " " + o.name;
		return tmp1.compareTo(tmp2);
	}

}

class MyMusicLibrary {
	private Set<Music> musicCollection = new TreeSet<Music>();

	public void add(Music m) {
		musicCollection.add(m);
	}
	
	public Set<Music> getRockMusic(){
		return this.musicCollection.stream().filter(m -> "rock".equalsIgnoreCase(m.genre)).collect(Collectors.toSet());
	}
	
	public Set<Music> getPopMusic(){
		return this.musicCollection.stream().filter(m -> "pop".equalsIgnoreCase(m.genre)).collect(Collectors.toSet());
	}

}

public class MusicLibraryExercise {
	public static void main(String[] args) {
		MyMusicLibrary library = new MyMusicLibrary();
		library.add(new Music("Thunderstruck", "AC/DC", "rock", false, false));
		library.add(new Music("Who Made Who", "AC/DC", "rock", false, false));
		library.add(new Music("Whole Lotta Rosie", "AC/DC", "rock", false, false));
		library.add(new Music("Growin Up", "Bruce Springsteen", "pop", false, false));
		library.add(new Music("Crossroads", "Cream", "pop", false, false));
		library.add(new Music("Jean Genie", "David Bowie", "rap", false, false));
		library.add(new Music("Boulevard Of Broken Dreams", "Green Day", "rap", false, false));
		library.add(new Music("Little Queen", "Heart", "folk", false, false));
		library.add(new Music("Nothing Is Easy", "Jethro Tull", "folk", false, false));
		library.add(new Music("All Along the Watchtower", "Jimi Hendrix", "indie", false, false));
		library.add(new Music("Wheel in the Sky", "Journey", "rock", false, false));
		library.add(new Music("Black Dog", "Led Zeppelin", "alternative", false, false));
		library.add(new Music("I'm Down", "The Beatles", "classic", false, false));
		library.add(new Music("No woman no cry", "Bob Marley", "raggae", false, false));
		library.add(new Music("Bridge Over Troubled Water", "Simon And Garfunkel", "punk", false, false));
		
		System.out.println(library.getRockMusic());
	}
}

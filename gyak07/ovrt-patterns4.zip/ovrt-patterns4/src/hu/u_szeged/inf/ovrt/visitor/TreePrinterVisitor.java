package hu.u_szeged.inf.ovrt.visitor;

public class TreePrinterVisitor implements FileSystemVisitor {

	private int indent = 0;

	@Override
	public void visit(VisitableFolder folder) {
		this.printIndent();
		System.out.println(folder);
		this.indent += 2;
	}

	@Override
	public void visitEnd(VisitableFolder folder) {
		this.indent -= 2;
	}

	@Override
	public void visit(VisitableFile file) {
		this.printIndent();
		System.out.println(file);
	}

	private void printIndent() {
		for (int i = 0; i < this.indent; i++) {
			System.out.print(" ");
		}
	}

}

package hu.u_szeged.inf.ovrt.observer_java;

import java.util.Observable;
import java.util.Observer;

public class Person implements Observer {

	private String personName;

	public Person(String personName) {
		this.personName = personName;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public void update(Observable arg0, Object arg1) {
		System.out.println(String.format("Hello %s! Product is now %s.", personName, arg1));
	}

}
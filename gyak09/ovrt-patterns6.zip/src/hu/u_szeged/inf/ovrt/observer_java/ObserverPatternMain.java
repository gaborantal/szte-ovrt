package hu.u_szeged.inf.ovrt.observer_java;


public class ObserverPatternMain {

	public static void delayedNotify(Product p, String availability){
		System.out.println(p + " is " + availability);
		try{
			p.setAvailability(availability);
			Thread.sleep((long) (1000+(Math.random()*1500)));
		}catch(InterruptedException ie){
			ie.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		Person james = new Person("James");
		Person john = new Person("John");

		Product samsungMobile = new Product("Samsung", "Mobile", "Not available");

		// Notify me when product is available
		samsungMobile.registerObserver(james);
		samsungMobile.registerObserver(john);

		// Now product is available
		delayedNotify(samsungMobile, "Available");
		delayedNotify(samsungMobile, "Available");
		
		delayedNotify(samsungMobile, "Out of stock");
		delayedNotify(samsungMobile, "Available");
		delayedNotify(samsungMobile, "Available");
		delayedNotify(samsungMobile, "Available");
		delayedNotify(samsungMobile, "Available");
		delayedNotify(samsungMobile, "Available");
		delayedNotify(samsungMobile, "Out of stock");
		

	}
}
package hu.u_szeged.inf.ovrt.observer;

public interface Observer {
	public void update(String availability);
}

package hu.u_szeged.inf.ovrt.observer_feladat;

import java.util.Observable;
import java.util.Observer;

class Licitalo implements Observer {

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		
	}
}

public class LicitMain {

}

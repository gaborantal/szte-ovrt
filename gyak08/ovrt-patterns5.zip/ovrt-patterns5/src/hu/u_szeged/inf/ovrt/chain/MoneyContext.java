package hu.u_szeged.inf.ovrt.chain;

import java.util.HashMap;
import java.util.Map;

public class MoneyContext {

	private int requestedMoney;
	private int moneyLeft;
	private Map<Integer, Integer> cash;

	public MoneyContext(int requestedMoney) {
		super();
		this.requestedMoney = requestedMoney;
		this.moneyLeft = requestedMoney;
		this.cash = new HashMap<>();
	}

	public void addCash(int note) {
		int num = 0;
		if (cash.containsKey(note)) {
			num = cash.get(note);
		}
		cash.put(note, ++num);
		moneyLeft -= note;
	}

	public int getMoneyLeft() {
		return moneyLeft;
	}

	@Override
	public String toString() {
		return String.format("MoneyRequest [requestedMoney=%s, cash=%s]",
				requestedMoney, cash);
	}

}

package hu.u_szeged.inf.ovrt.builder;

public class Client {

	public static void main(String[] args) {
		// hard to maintain, hard to read
		Coffee bad1 = new Coffee(1, 2, 2, 0, true, false, "Brasil");
		System.out.println(bad1);

		// easy to maintain, easy to read
		Coffee good1 = Coffee.builder().withSpoons(1).withSugar(2).withMilk(2).withCream().from("Brasil").build();
		System.out.println(good1);

		// hard to maintain, hard to read
		Coffee bad2 = new Coffee(0, 0, 0, 1, false, true, null);
		System.out.println(bad2);

		// easy to maintain, easy to read
		Coffee good2 = Coffee.builder().withWater(1).decaf().build();
		System.out.println(good2);
	}

}

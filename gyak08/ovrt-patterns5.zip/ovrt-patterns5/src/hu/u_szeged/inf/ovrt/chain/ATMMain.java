package hu.u_szeged.inf.ovrt.chain;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

interface MoneyHandler {
	public boolean handleRequest(MoneyContext req);

	public MoneyHandler next();
}

abstract class ConcreteHandler implements MoneyHandler {

	protected int amount;

	public ConcreteHandler(int amount) {
		super();
		this.amount = amount;
	}

	@Override
	public boolean handleRequest(MoneyContext req) {
		while (req.getMoneyLeft() >= this.amount) {
			req.addCash(this.amount);
		}
		return req.getMoneyLeft() == 0;
	}

}

class HandleThousand extends ConcreteHandler {

	public HandleThousand() {
		super(1000);
	}

	@Override
	public MoneyHandler next() {
		return new HandleHundred();
	}

}

class HandleHundred extends ConcreteHandler {

	public HandleHundred() {
		super(100);
	}

	@Override
	public MoneyHandler next() {
		return new HandleTen();
	}

}

class HandleTen extends ConcreteHandler {

	public HandleTen() {
		super(10);
	}

	@Override
	public MoneyHandler next() {
		return null;
	}

}

class ATM {
	public List<MoneyHandler> handlers;

	public ATM(MoneyHandler... commands) {
		this.handlers = Arrays.asList(commands);
	}

	public void needCash(MoneyContext req) {
		for (MoneyHandler command : handlers) {
			boolean shouldStop = command.handleRequest(req);

			if (shouldStop) {
				return;
			}
		}
	}
}

public class ATMMain {
	private static final Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Money needed?");
		int money = sc.nextInt();
		MoneyContext mr = new MoneyContext(money);
		ATM atm = new ATM(new HandleThousand(), new HandleHundred(),
				new HandleTen());
		atm.needCash(mr);
		System.out.println(mr);
	}
}

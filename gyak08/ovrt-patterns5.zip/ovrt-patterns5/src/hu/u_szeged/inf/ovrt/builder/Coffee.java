package hu.u_szeged.inf.ovrt.builder;

public class Coffee {

	private int spoons;
	private int sugar;
	private int milk;
	private int water;
	private boolean cream;
	private boolean decaf;
	private String countryOfOrigin;

	public Coffee() {
	}

	public Coffee(int spoons, int sugar, int milk, int water, boolean cream,
			boolean decaf, String countryOfOrigin) {
		super();
		this.spoons = spoons;
		this.sugar = sugar;
		this.milk = milk;
		this.water = water;
		this.cream = cream;
		this.decaf = decaf;
		this.countryOfOrigin = countryOfOrigin;
	}

	// builder

	protected static class CoffeeBuilder {

		private Coffee coffee;

		protected CoffeeBuilder() {
			this.coffee = new Coffee();
		}

		public CoffeeBuilder withSpoons(int spoons) {
			this.coffee.setSpoons(spoons);
			return this;
		}

		public CoffeeBuilder withSugar(int sugar) {
			this.coffee.setSugar(sugar);
			return this;
		}

		public CoffeeBuilder withMilk(int milk) {
			this.coffee.setMilk(milk);
			return this;
		}

		public CoffeeBuilder withWater(int water) {
			this.coffee.setWater(water);
			return this;
		}

		public CoffeeBuilder withCream() {
			this.coffee.setCream(true);
			return this;
		}

		public CoffeeBuilder decaf() {
			this.coffee.setDecaf(true);
			return this;
		}

		public CoffeeBuilder from(String contryOfOrigin) {
			this.coffee.setCountryOfOrigin(contryOfOrigin);
			return this;
		}

		public Coffee build() {
			return this.coffee;
		}

	}

	public static CoffeeBuilder builder() {
		return new CoffeeBuilder();
	}

	// boilerplate

	public int getSpoons() {
		return this.spoons;
	}

	public void setSpoons(int spoons) {
		this.spoons = spoons;
	}

	public int getSugar() {
		return this.sugar;
	}

	public void setSugar(int sugar) {
		this.sugar = sugar;
	}

	public int getMilk() {
		return this.milk;
	}

	public void setMilk(int milk) {
		this.milk = milk;
	}

	public int getWater() {
		return this.water;
	}

	public void setWater(int water) {
		this.water = water;
	}

	public boolean isCream() {
		return this.cream;
	}

	public void setCream(boolean cream) {
		this.cream = cream;
	}

	public boolean isDecaf() {
		return this.decaf;
	}

	public void setDecaf(boolean decaf) {
		this.decaf = decaf;
	}

	public String getCountryOfOrigin() {
		return this.countryOfOrigin;
	}

	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}

	@Override
	public String toString() {
		return "Coffee [spoons=" + this.spoons + ", sugar=" + this.sugar
				+ ", milk=" + this.milk + ", water=" + this.water + ", cream="
				+ this.cream + ", decaf=" + this.decaf + ", countryOfOrigin="
				+ this.countryOfOrigin + "]";
	}

}
